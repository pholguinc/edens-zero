﻿#!/usr/bin/env bash

echo "Archivo generado con PatchMe 1.0.0"
echo
if [[ ! $(which xdelta3) ]]; then
  echo "No se encuentra el ejecutable de xdelta. Saliendo."
  exit -1
else
if [[ ! -f "EDENS ZERO 04 [enc].mkv" ]]; then
  echo "No se encuentra el fichero de origen: EDENS ZERO 04 [enc].mkv"
  exit -1
fi

echo "Parcheando el archivo: EDENS ZERO 04 [enc].mkv"
xdelta3 -f -d -s "EDENS ZERO 04 [enc].mkv" "file01.xdelta" "[DraKuro] Edens Zero 04 [E0289E6E].mkv"

echo "Proceso finalizado."
fi

exit 0
