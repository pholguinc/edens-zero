﻿#!/usr/bin/env bash

echo "Archivo generado con PatchMe 1.0.0"
echo
if [[ ! $(which xdelta3) ]]; then
  echo "No se encuentra el ejecutable de xdelta. Saliendo."
  exit -1
else
if [[ ! -f "[DraKuro] Edens Zero 01 [20F8536D].mkv" ]]; then
  echo "No se encuentra el fichero de origen: [DraKuro] Edens Zero 01 [20F8536D].mkv"
  exit -1
fi

echo "Parcheando el archivo: [DraKuro] Edens Zero 01 [20F8536D].mkv"
xdelta3 -f -d -s "[DraKuro] Edens Zero 01 [20F8536D].mkv" "[DraKuro] Edens Zero 01v2 [C585B1BE].xdelta" "[DraKuro] Edens Zero 01v2 [C585B1BE].mkv"

echo "Proceso finalizado."
fi

exit 0
