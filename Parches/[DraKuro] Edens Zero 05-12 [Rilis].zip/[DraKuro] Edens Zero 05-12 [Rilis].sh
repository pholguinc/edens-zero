﻿#!/usr/bin/env bash

echo "Archivo generado con PatchMe 1.0.0"
echo
if [[ ! $(which xdelta3) ]]; then
  echo "No se encuentra el ejecutable de xdelta. Saliendo."
  exit -1
else
if [[ ! -f "EDENS ZERO 05v2 [enc] [78574DE2].mkv" ]]; then
  echo "No se encuentra el fichero de origen: EDENS ZERO 05v2 [enc] [78574DE2].mkv"
  exit -1
fi

echo "Parcheando el archivo: EDENS ZERO 05v2 [enc] [78574DE2].mkv"
xdelta3 -f -d -s "EDENS ZERO 05v2 [enc] [78574DE2].mkv" "file01.xdelta" "[DraKuro] Edens Zero 05 [705C5398].mkv"

if [[ ! -f "EDENS ZERO 06 [enc] [7920A79A].mkv" ]]; then
  echo "No se encuentra el fichero de origen: EDENS ZERO 06 [enc] [7920A79A].mkv"
  exit -1
fi

echo "Parcheando el archivo: EDENS ZERO 06 [enc] [7920A79A].mkv"
xdelta3 -f -d -s "EDENS ZERO 06 [enc] [7920A79A].mkv" "file02.xdelta" "[DraKuro] Edens Zero 06 [32271D1E].mkv"

if [[ ! -f "EDENS ZERO 07v2 [enc] [D6E7A3A0].mkv" ]]; then
  echo "No se encuentra el fichero de origen: EDENS ZERO 07v2 [enc] [D6E7A3A0].mkv"
  exit -1
fi

echo "Parcheando el archivo: EDENS ZERO 07v2 [enc] [D6E7A3A0].mkv"
xdelta3 -f -d -s "EDENS ZERO 07v2 [enc] [D6E7A3A0].mkv" "file03.xdelta" "[DraKuro] Edens Zero 07 [C6BFFBF2].mkv"

if [[ ! -f "EDENS ZERO 08 [enc] [62D3E3F5].mkv" ]]; then
  echo "No se encuentra el fichero de origen: EDENS ZERO 08 [enc] [62D3E3F5].mkv"
  exit -1
fi

echo "Parcheando el archivo: EDENS ZERO 08 [enc] [62D3E3F5].mkv"
xdelta3 -f -d -s "EDENS ZERO 08 [enc] [62D3E3F5].mkv" "file04.xdelta" "[DraKuro] Edens Zero 08 [45172AD9].mkv"

if [[ ! -f "EDENS ZERO 09 [enc] [015EEDE2].mkv" ]]; then
  echo "No se encuentra el fichero de origen: EDENS ZERO 09 [enc] [015EEDE2].mkv"
  exit -1
fi

echo "Parcheando el archivo: EDENS ZERO 09 [enc] [015EEDE2].mkv"
xdelta3 -f -d -s "EDENS ZERO 09 [enc] [015EEDE2].mkv" "file05.xdelta" "[DraKuro] Edens Zero 09 [EFD0F6DD].mkv"

if [[ ! -f "EDENS ZERO 10 [enc] [AAA1A71C].mkv" ]]; then
  echo "No se encuentra el fichero de origen: EDENS ZERO 10 [enc] [AAA1A71C].mkv"
  exit -1
fi

echo "Parcheando el archivo: EDENS ZERO 10 [enc] [AAA1A71C].mkv"
xdelta3 -f -d -s "EDENS ZERO 10 [enc] [AAA1A71C].mkv" "file06.xdelta" "[DraKuro] Edens Zero 10 [103C7FE7].mkv"

if [[ ! -f "EDENS ZERO 11 [enc] [30463016].mkv" ]]; then
  echo "No se encuentra el fichero de origen: EDENS ZERO 11 [enc] [30463016].mkv"
  exit -1
fi

echo "Parcheando el archivo: EDENS ZERO 11 [enc] [30463016].mkv"
xdelta3 -f -d -s "EDENS ZERO 11 [enc] [30463016].mkv" "file07.xdelta" "[DraKuro] Edens Zero 11 [DBCE3E61].mkv"

if [[ ! -f "EDENS ZERO 12 [enc] [6E0274E4].mkv" ]]; then
  echo "No se encuentra el fichero de origen: EDENS ZERO 12 [enc] [6E0274E4].mkv"
  exit -1
fi

echo "Parcheando el archivo: EDENS ZERO 12 [enc] [6E0274E4].mkv"
xdelta3 -f -d -s "EDENS ZERO 12 [enc] [6E0274E4].mkv" "file08.xdelta" "[DraKuro] Edens Zero 12 [68F74477].mkv"

echo "Proceso finalizado."
fi

exit 0
