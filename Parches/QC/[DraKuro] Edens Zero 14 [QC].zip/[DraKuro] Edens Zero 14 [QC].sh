﻿#!/usr/bin/env bash

echo "Archivo generado con PatchMe 1.0.0"
echo
if [[ ! $(which xdelta3) ]]; then
  echo "No se encuentra el ejecutable de xdelta. Saliendo."
  exit -1
else
if [[ ! -f "EDENS ZERO 14 [enc] [30C236FE].mkv" ]]; then
  echo "No se encuentra el fichero de origen: EDENS ZERO 14 [enc] [30C236FE].mkv"
  exit -1
fi

echo "Parcheando el archivo: EDENS ZERO 14 [enc] [30C236FE].mkv"
xdelta3 -f -d -s "EDENS ZERO 14 [enc] [30C236FE].mkv" "file01.xdelta" "[DraKuro] Edens Zero 14 [QC] [F487AD1C].mkv"

echo "Proceso finalizado."
fi

exit 0
