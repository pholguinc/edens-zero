﻿#!/usr/bin/env bash

echo "Archivo generado con PatchMe 1.0.0"
echo
if [[ ! $(which xdelta3) ]]; then
  echo "No se encuentra el ejecutable de xdelta. Saliendo."
  exit -1
else
if [[ ! -f "EDENS ZERO 01v2 [enc] [107F87AE].mkv" ]]; then
  echo "No se encuentra el fichero de origen: EDENS ZERO 01v2 [enc] [107F87AE].mkv"
  exit -1
fi

echo "Parcheando el archivo: EDENS ZERO 01v2 [enc] [107F87AE].mkv"
xdelta3 -f -d -s "EDENS ZERO 01v2 [enc] [107F87AE].mkv" "[DraKuro] Edens Zero 01v3 [AC682581].xdelta" "[DraKuro] Edens Zero 01v3 [AC682581].mkv"

if [[ ! -f "EDENS ZERO 02 [enc] [4C5C6038].mkv" ]]; then
  echo "No se encuentra el fichero de origen: EDENS ZERO 02 [enc] [4C5C6038].mkv"
  exit -1
fi

echo "Parcheando el archivo: EDENS ZERO 02 [enc] [4C5C6038].mkv"
xdelta3 -f -d -s "EDENS ZERO 02 [enc] [4C5C6038].mkv" "[DraKuro] Edens Zero 02 [27322976].xdelta" "[DraKuro] Edens Zero 02 [27322976].mkv"

if [[ ! -f "EDENS ZERO 03 [enc] [8E5D18A1].mkv" ]]; then
  echo "No se encuentra el fichero de origen: EDENS ZERO 03 [enc] [8E5D18A1].mkv"
  exit -1
fi

echo "Parcheando el archivo: EDENS ZERO 03 [enc] [8E5D18A1].mkv"
xdelta3 -f -d -s "EDENS ZERO 03 [enc] [8E5D18A1].mkv" "[DraKuro] Edens Zero 03 [A5FF632B].xdelta" "[DraKuro] Edens Zero 03 [A5FF632B].mkv"

echo "Proceso finalizado."
fi

exit 0
